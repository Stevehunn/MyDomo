package com.example.mydomo.ui.alarme;

import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.lifecycle.ViewModel;

import com.example.mydomo.R;


public class AlarmeViewModel extends ViewModel {





}