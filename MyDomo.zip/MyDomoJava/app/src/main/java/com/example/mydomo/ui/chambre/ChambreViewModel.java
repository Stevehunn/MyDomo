package com.example.mydomo.ui.chambre;

import androidx.lifecycle.ViewModel;

public class ChambreViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}